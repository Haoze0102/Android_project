package com.example.final_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private ImageView img_show;
    private Button bt_pre,bt_next,bt_view;
    private TextView tv_info;
    private RatingBar rb_rating;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img_show=findViewById(R.id.img_show);
        bt_pre=findViewById(R.id.bt_pre);
        bt_next=findViewById(R.id.bt_next);
        bt_view=findViewById(R.id.bt_view);
        tv_info=findViewById(R.id.tv_info);
        rb_rating=findViewById(R.id.rb_rating);
    }
}
